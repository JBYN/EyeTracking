#source
#https://docs.opencv.org/3.4.3/d7/d8b/tutorial_py_face_detection.html
import cv2
import numpy as np

#Detecting the 2 eyes on an image of a person using haarcascades.
#When the 2 eyes are detected, the region where they are detected are returned.
#Otherwise the value None will be returned
#@param face_cascade: is a CascadeClassifier which is used to detect faces
#@param eye_cascade: is a CascadeClassifier which is used to detect eyes
#@param b:
#@param img: the image where the eyes has to be detect on
#@return: [right eye, left eye]
def detect_2eyesOf1person(face_cascade,eye_cascade,b,img):
    two_eyes = False #Not 2 eyes detected yet       
    
    #to make it possible to detect faces the capture has to be in grayscale. 
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray,1.3,5)
    if faces != ():
        print("Face detected")
        #getting the coördinates of the detected faces
        for (x,y,w,h) in faces:
            #print(x,y,w,h)
            roi_gray = gray[y:y+h, x:x+w] #pixels of the region of interest
            roi_color = img[y:y+h, x:x+w]
            
            #looking for eyes in the region where the faces are detected
            eyes = eye_cascade.detectMultiScale(roi_gray)
            eye_color_R = (0,0,255) #Red
            eye_color_L = (255,0,0) #Blue
            eye_stroke = 2
            nr_eyes = 0  
            eye_1 = []
            eye_2 = []
            #getting the coördinates of the detected eyes
            for (eye_x,eye_y,eye_w,eye_h) in eyes:
                    nr_eyes += 1
                    if nr_eyes == 1:
                        eye_1 = [eye_x,eye_y,eye_h, eye_w]
                    elif nr_eyes == 2:
                        eye_2 = [eye_x,eye_y,eye_h, eye_w] 
            
            #Check that the detected eyes are a left and right eye            
            if eye_1 != [] and eye_2 != []:
                print("eyes detected")
                two_eyes = True
                if eye_1[0] < eye_2[0] and eye_1[3] < eye_2[0]:
                    #right eye
                    cv2.rectangle(roi_color, (eye_1[0], eye_1[1]), (eye_1[0] + eye_1[3], eye_1[1] + eye_1[2]), eye_color_R, eye_stroke)
                    right_eye = roi_color[eye_1[1]:eye_1[1]+eye_1[2], eye_1[0]:eye_1[0]+eye_1[3]]
                    #left eye
                    cv2.rectangle(roi_color, (eye_2[0], eye_2[1]), (eye_2[0] + eye_2[3], eye_2[1] + eye_2[2]), eye_color_L, eye_stroke)
                    left_eye = roi_color[eye_2[1]:eye_2[1]+eye_2[2], eye_2[0]:eye_2[0]+eye_2[3]]
                elif eye_2[0] < eye_1[0] and eye_2[3] < eye_1[0]:
                    #right eye
                    cv2.rectangle(roi_color, (eye_2[0], eye_2[1]), (eye_2[0] + eye_2[3], eye_2[1] + eye_2[2]), eye_color_R, eye_stroke)
                    right_eye = roi_color[eye_2[1]:eye_2[1]+eye_2[2], eye_2[0]:eye_2[0]+eye_2[3]]
                    #left eye
                    cv2.rectangle(roi_color, (eye_1[0], eye_1[1]), (eye_1[0] + eye_1[3], eye_1[1] + eye_1[2]), eye_color_L, eye_stroke)
                    left_eye = roi_color[eye_1[1]:eye_1[1]+eye_1[2], eye_1[0]:eye_1[0]+eye_1[3]]
                else:
                    two_eyes = False
            else:
                print("Not able to detect two eyes")

    else:
        print("No face detected")

    if not b:
        print("The camera is not working")
    
    if two_eyes == True:
#        print("RE1: " + str(right_eye))
        return [right_eye,left_eye]
    else:
        return None

#Detect the circle in the image. This circle represents the pupil of the eye.
#The x and y values of the center of the circle and the processed image are returned.
#When no circle is detected the value None will be returned.
#@param eye determine the circles on this image. (Image of an eye)
#@return [x,y,image]
def detect_eyeCenter(eye):
    #preprocessing the images
    print("preprocessing")
    eye_gray = cv2.cvtColor(eye, cv2.COLOR_BGR2GRAY,0)
    res_eye = cv2.resize(eye_gray,(400,400), interpolation = cv2.INTER_CUBIC)
    blur_eye = cv2.GaussianBlur(res_eye,(3,3),0)
    crop_eye = blur_eye[100:300,0:400]
    print("passed preprocessing")
#    cv2.imwrite("blur_eye1.png",crop_eye)
    
    #looking for circles with Hough transform
    print("detect pupil")
    eye_pupils = cv2.HoughCircles(crop_eye,cv2.HOUGH_GRADIENT,1,15,50,15,30,60)
    eye_pupils = np.uint16(np.around(eye_pupils))
    for pupil in eye_pupils[0,:]:
#        print("x: " + str(pupil[0]))
#        print("y: " + str(pupil[1]))
#        print("radius: " + str(pupil[2]))
        cv2.circle(crop_eye,(pupil[0],pupil[1]),int(pupil[2]/3),(0,255,0))
        return [pupil[0],pupil[1],crop_eye]